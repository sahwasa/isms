# Chart
Chart is a simple and **functional** charting library which currently supports bar charts. Implementations are done on-top of a HTML5 canvas element.
